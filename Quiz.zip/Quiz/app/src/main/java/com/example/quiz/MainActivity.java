package com.example.quiz;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private RadioGroup[] radioGroups = new RadioGroup[10];
    private int[] respostasCorretas = {1, 0, 1, 2, 1, 0, 2, 0, 0, 0}; // Índices das respostas corretas
    private Button btFinalizar;
    private TextView tvResultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btFinalizar = findViewById(R.id.btFinalizar);
        tvResultado = findViewById(R.id.tvResultado);

        //P saber qual radioGroup pertence
        for (int i = 0; i < 10; i++) {
            int idRadioGroupAtual = getResources().getIdentifier("radioGroup" + i, "id", getPackageName());
            radioGroups[i] = findViewById(idRadioGroupAtual);
        }

        btFinalizar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calcularPontuacao();
            }
        });
    }

    private void calcularPontuacao() {
        int pontuacao = 0;
        int naoRespondidas = 0;

        for (int i = 0; i < 10; i++) {
            int selecionado = radioGroups[i].getCheckedRadioButtonId();

            if (selecionado == -1) {
                naoRespondidas++;
                continue;
            }

            int resSelecionada;
            //padrao: rbOpcao"questao"_"alternativa"
            if (selecionado == getResources().getIdentifier("rbOpcao" + i + "_1", "id", getPackageName())) {
                resSelecionada = 0;
            } else if (selecionado == getResources().getIdentifier("rbOpcao" + i + "_2", "id", getPackageName())) {
                resSelecionada = 1;
            } else {
                resSelecionada = 2;
            }

            if (resSelecionada == respostasCorretas[i]) {
                pontuacao++;
            }
        }

        if (naoRespondidas > 0) {
            Toast.makeText(this, "Existem " + naoRespondidas + " questão(ões) sem responder!", Toast.LENGTH_SHORT).show();
            pontuacao = 0;
        }

        tvResultado.setText("Pontuação: " + pontuacao + "/10");
    }
}
