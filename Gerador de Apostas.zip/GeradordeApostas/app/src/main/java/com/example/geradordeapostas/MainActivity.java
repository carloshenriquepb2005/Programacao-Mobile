package com.example.geradordeapostas;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    RadioGroup radioGroup;
    Button btGerar;
    TextView tvResultado;
    private final Random random = new Random();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        radioGroup = findViewById(R.id.radioGroup);
        btGerar = findViewById(R.id.btGerar);
        tvResultado = findViewById(R.id.tvResultado);

        btGerar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gerarNumeros();
            }
        });
    }

    private void gerarNumeros() {
        int selectedId = radioGroup.getCheckedRadioButtonId();
        if (selectedId == -1) {
            Toast.makeText(MainActivity.this, "Por favor, preencha o campo da loteria!", Toast.LENGTH_SHORT).show();
            return;
        }
        RadioButton selectedRadio = findViewById(selectedId);
        String loteria = selectedRadio.getText().toString();

        switch (loteria) {
            case "Mega-Sena": gerarNumerosLoteria("Mega-Sena", 6, 60); break;
            case "Quina": gerarNumerosLoteria("Quina", 5, 80); break;
            case "Lotomania": gerarNumerosLoteria("Lotomania", 50, 100); break;
            case "Dupla Sena": gerarNumerosLoteria("Dupla Sena", 6, 50); break;
        }
    }

    private void gerarNumerosLoteria(String nome, int qtd, int max) {
        ArrayList<Integer> numeros = new ArrayList<>();
        for (int i = 1; i <= max; i++) {
            numeros.add(i);
        }
        Collections.shuffle(numeros, random);
        tvResultado.setText(numeros.subList(0, qtd).toString());
    }
}
