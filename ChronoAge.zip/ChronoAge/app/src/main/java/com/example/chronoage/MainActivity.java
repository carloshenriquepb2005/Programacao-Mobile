package com.example.chronoage;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    EditText edDataNascimento;
    Button btCalcular;
    TextView tvResultado;
    Calendar dataNascimento = Calendar.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edDataNascimento = findViewById(R.id.edDataNascimento);
        btCalcular = findViewById(R.id.btCalcular);
        tvResultado = findViewById(R.id.tvResultado);

        // Exibir o DatePicker ao tocar no EditText
        edDataNascimento.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                esconderTeclado();
                mostrarDatePicker();
            }
        });

        btCalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (edDataNascimento.getText().toString().isEmpty()) {
                    Toast.makeText(MainActivity.this, "Por favor, insira a data de nascimento!", Toast.LENGTH_SHORT).show();
                    return;
                }

                long diferencaMillis = new Date().getTime() - dataNascimento.getTimeInMillis();
                long segundos = diferencaMillis / 1000;
                long minutos = segundos / 60;
                long horas = minutos / 60;
                long dias = horas / 24;
                long meses = dias / 30;
                long anos = dias / 365;

                String resultado = anos + " anos\n" +
                        meses + " meses\n" +
                        dias + " dias\n" +
                        horas + " horas\n" +
                        minutos + " minutos\n" +
                        segundos + " segundos";

                tvResultado.setText(resultado);
                esconderTeclado();
            }
        });
    }

    private void mostrarDatePicker() {
        int ano = dataNascimento.get(Calendar.YEAR);
        int mes = dataNascimento.get(Calendar.MONTH);
        int dia = dataNascimento.get(Calendar.DAY_OF_MONTH);

        new DatePickerDialog(MainActivity.this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                dataNascimento.set(year, month, dayOfMonth);
                SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
                edDataNascimento.setText(format.format(dataNascimento.getTime()));
            }
        }, ano, mes, dia).show();
    }

    private void esconderTeclado() {
        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        View viewAtual = getCurrentFocus();
        if (viewAtual != null) {
            imm.hideSoftInputFromWindow(viewAtual.getWindowToken(), 0);
        }
    }
}
