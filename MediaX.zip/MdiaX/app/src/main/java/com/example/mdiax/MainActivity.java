package com.example.mdiax;

import android.content.Context;
import android.os.Bundle;
import android.view.View;

import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;


public class MainActivity extends AppCompatActivity {
    Button btCalcular, btLimpar;
    EditText edDisciplina, edP1, edP2, edP3, edFaltas;
    TextView tvMedia, tvSituacao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        btCalcular   = (Button) findViewById(R.id.btCalcular);
        btLimpar     = (Button) findViewById(R.id.btLimpar);

        edDisciplina = (EditText) findViewById(R.id.edDisciplina);
        edP1      = (EditText) findViewById(R.id.edP1);
        edP2      = (EditText) findViewById(R.id.edP2);
        edP3      = (EditText) findViewById(R.id.edP3);
        edFaltas     = (EditText) findViewById(R.id.edFaltas);

        tvMedia      = (TextView) findViewById(R.id.tvMedia);
        tvSituacao   = (TextView) findViewById(R.id.tvSituacao);

        btCalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double p1, p2, p3, media, sel1, sel2;
                int faltas;
                String situacao;

                esconderTeclado(); //Chamando metodo para esconder teclado

                if (edP1.getText().toString().isEmpty() || edP2.getText().toString().isEmpty() || edP3.getText().toString().isEmpty() || edFaltas.getText().toString().isEmpty() ) {
                    Toast.makeText(MainActivity.this, "Por favor, preencha todos os campos!", Toast.LENGTH_SHORT).show();
                }
                else {
                    p1 = Double.parseDouble(edP1.getText().toString());
                    p2 = Double.parseDouble(edP2.getText().toString());
                    p3 = Double.parseDouble(edP3.getText().toString());

                    faltas = Integer.parseInt(edFaltas.getText().toString());

                    sel1 = 0;
                    sel2 = 0;

                    if (p1 >= p2 && p1 >= p3) {
                        sel1 = p1;
                        if (p2 >= p3) {
                            sel2 = p2;
                        } else {
                            sel2 = p3;
                        }
                    } else if (p2 >= p1 && p2 >= p3) {
                        sel1 = p2;
                        if (p1 >= p3) {
                            sel2 = p1;
                        } else {
                            sel2 = p3;
                        }
                    } else {
                        sel1 = p3;
                        if (p1 >= p2) {
                            sel2 = p1;
                        } else {
                            sel2 = p2;
                        }
                    }

                    media = (sel1 + sel2) / 2;

                    if (media >= 6 && faltas <= 5) {
                        tvSituacao.setText("Aprovado");
                    } else if(media < 6 && faltas <= 5){
                        tvSituacao.setText("Retido por nota");
                    } else if(media >= 6){
                        tvSituacao.setText("Retido por falta");
                    } else if(media < 6){
                        tvSituacao.setText("Retido por nota e falta");
                    }
                    tvMedia.setText(String.valueOf(media));
                }
            }
        });

        //Botao Limpar
        btLimpar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                edDisciplina.setText("");
                edP1.setText("");
                edP2.setText("");
                edP3.setText("");
                edFaltas.setText("");
                tvMedia.setText("");
                tvSituacao.setText("");
            }
        });



        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    private void esconderTeclado() {
        View viewAtual = getCurrentFocus();
        if (viewAtual != null) {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(viewAtual.getWindowToken(), 0);
        }
    }

}