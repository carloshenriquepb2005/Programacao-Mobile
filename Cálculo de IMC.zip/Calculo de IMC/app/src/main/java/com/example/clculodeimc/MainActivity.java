package com.example.clculodeimc;

import android.os.Bundle;
import android.view.View;

import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    Button btCalcular;
    EditText edPeso, edAltura;
    TextView tvImc, tvEstado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        btCalcular = (Button) findViewById(R.id.btCalcular);

        edPeso = (EditText) findViewById(R.id.edPeso);
        edAltura = (EditText) findViewById(R.id.edAltura);

        tvImc = (TextView) findViewById(R.id.tvImc);
        tvEstado = (TextView) findViewById(R.id.tvEstado);


        btCalcular.setOnClickListener(new View.OnClickListener() {
            @Override

            public void onClick(View view) {
                InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                view = getCurrentFocus();
                if (view != null) {
                    imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
                }

                double peso, altura, imc;

                if (edPeso.getText().toString().isEmpty() || edAltura.getText().toString().isEmpty()) {
                    Toast.makeText(MainActivity.this, "Por favor, preencha todos os campos!", Toast.LENGTH_SHORT).show();
                } else {
                    altura = Double.parseDouble(edAltura.getText().toString());
                    peso = Double.parseDouble(edPeso.getText().toString());

                    imc = (peso / (altura * altura));

                    tvImc.setText(String.valueOf(imc));

                    if (imc < 18.5) {
                        tvEstado.setText("Abaixo do peso normal");
                    } else if (imc < 24.9) {
                        tvEstado.setText("Peso normal");
                    } else if (imc < 29.9) {
                        tvEstado.setText("Excesso de peso");
                    } else if (imc < 34.9) {
                        tvEstado.setText("Obesidade classe I");
                    } else if (imc < 39.9) {
                        tvEstado.setText("Obesidade classe II");
                    } else {
                        tvEstado.setText("Obesidade classe III");
                    }
                }
            }

    });

        ViewCompat.setOnApplyWindowInsetsListener(

    findViewById(R.id.main), (v,insets)->
    {
        Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
        v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
        return insets;
    });
}

}